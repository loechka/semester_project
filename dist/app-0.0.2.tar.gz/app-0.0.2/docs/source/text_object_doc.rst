Class TextObject 
================
.. automodule:: text_object
   :members:
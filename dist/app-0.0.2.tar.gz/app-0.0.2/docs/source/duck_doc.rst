Class Duck
============
.. automodule:: duck
   :members:
Class Image 
============
.. automodule:: image
   :members:
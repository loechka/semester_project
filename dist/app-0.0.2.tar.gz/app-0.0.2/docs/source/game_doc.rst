Class Game
============
.. automodule:: game
   :members:
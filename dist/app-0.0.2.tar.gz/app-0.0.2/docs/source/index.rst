.. Fly_game documentation master file, created by
   sphinx-quickstart on Sun Jun  6 13:28:57 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Fly_game's documentation!
====================================

This is documentation for classed used in Fly_game and their functions.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   bonus_doc
   button_doc
   duck_doc
   game_object_doc
   game_doc
   image_doc
   main_file_doc
   text_object_doc
   wall_doc
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

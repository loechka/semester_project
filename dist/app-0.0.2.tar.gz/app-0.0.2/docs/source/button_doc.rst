Class Button
============
.. automodule:: button
   :members:
Class Rocket 
============
.. automodule:: main_file
   :members:
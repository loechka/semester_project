Class Bonus 
============
.. automodule:: bonus
   :members:
   :private-members: